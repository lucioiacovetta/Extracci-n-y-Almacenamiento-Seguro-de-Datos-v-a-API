# Importaciones argentinas por uso económico (API del INDEC)

Script en Python que consulta la API oficial del INDEC y arma, para los últimos 12 meses publicados, cuánto importó la Argentina en cada **uso económico** (bienes de capital, bienes intermedios, combustibles, piezas y accesorios, bienes de consumo, vehículos de pasajeros), con su peso en el total del mes y la variación contra el mismo mes del año anterior.

## Fuente

[Catálogo API-INDEC](https://api.indec.gob.ar) (servicio en beta desde noviembre de 2026). El script hace dos pedidos `GET`:

| Servicio | Para qué |
|---|---|
| `comercio_exterior_importacion_bienes` | El valor CIF en dólares de las importaciones, que la API devuelve ya sumado por mes (`Periodo`) y uso económico (`uso_economico_cod`) |
| `comercio_exterior_nomenclaturas` | El nombre de cada código de uso económico |

Metodología: INDEC, *Metodología de comercio exterior* (Metodología INDEC n° 26), https://www.indec.gob.ar/ftp/cuadros/economia/metodologia_comex.pdf

Códigos de uso económico: 1 Bienes de capital · 2 Bienes intermedios · 3 Combustibles y lubricantes · 4 Piezas y accesorios para bienes de capital · 5 Bienes de consumo · 6 Vehículos automotores de pasajeros · 9 Resto · X Desconocido.

## Archivo de salida: `data_extracted.csv`

Una fila por mes y uso económico.

| Columna | Descripción |
|---|---|
| `periodo` | Mes, `AAAA-MM` |
| `uso_economico_cod` | Código que identifica el uso económico |
| `uso_economico` | Nombre del uso económico |
| `valor_cif_millones_usd` | Valor importado, en millones de dólares CIF |
| `participacion_pct` | Porcentaje del total importado ese mes |
| `var_interanual_pct` | Variación porcentual contra el mismo mes del año anterior |

## Requisitos

- Python 3.9 o superior (o Google Colab, que ya lo trae).
- Una cuenta gratuita en la API del INDEC y su token:
  1. Registrarse en https://api.indec.gob.ar/register y confirmar con el código que llega por correo.
  2. En **Gestionar la cuenta**, generar el token. Se muestra una sola vez: copiarlo en ese momento.

## Instalación

```bash
git clone https://github.com/<tu-usuario>/<tu-repo>.git
cd <tu-repo>
pip install -r requirements.txt
```

## Configuración

El token **no** va en el código. Se guarda en un archivo `.env`, que `.gitignore` deja fuera del repositorio:

```bash
cp .env.example .env
# abrir .env y reemplazar el texto por el token
```

`.env` queda así:

```
INDEC_API_TOKEN=tu_token
```

El script lo lee con `python-dotenv`.

## Ejecución

```bash
python extraer_importaciones_indec.py
```

Escribe `data_extracted.csv` en la misma carpeta y muestra en pantalla el último mes.

### En Google Colab

Abrir `Importaciones_INDEC_Colab.ipynb` en Colab y correr las celdas en orden. El notebook crea los archivos, pide el token sin mostrarlo en pantalla, ejecuta el script, muestra las tablas y un gráfico, y arma un `.zip` para subir al repositorio (sin `.env`).

## Manejo de errores

Si algo falla, el script muestra un mensaje claro y termina con código 1, sin traceback:

- **Sin token** en `.env`: explica cómo crearlo.
- **401**: token mal copiado o vencido.
- **403 / 404 / 400**: sin permiso, servicio inexistente o pedido mal armado.
- **429, 5xx, sin conexión o demora**: reintenta hasta 4 veces, esperando cada vez más, y después avisa que se pruebe más tarde.
- **Respuesta inesperada**: si la API no devuelve las columnas esperadas, lo dice.

`data_extracted.csv` se escribe solo si la extracción terminó bien.

## Estructura del repositorio

```
├── extraer_importaciones_indec.py   # script de extracción
├── data_extracted.csv               # salida
├── Importaciones_INDEC_Colab.ipynb  # paso a paso en Colab
├── requirements.txt
├── .env.example                     # plantilla del .env (sin token)
├── .gitignore
└── README.md
```

## Notas

- Los últimos meses son provisorios: el INDEC revisa las cifras de meses anteriores en cada publicación, así que correr el script otro día puede dar valores algo distintos.
- Al usar los datos hay que citar **"Fuente: INDEC"** y el servicio de datos consultado.
