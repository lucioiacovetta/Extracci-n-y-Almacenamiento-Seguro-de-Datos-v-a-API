"""
Importaciones de la Argentina por uso económico, mes a mes, en los últimos 12 meses publicados.

Fuente: INDEC, Catálogo API-INDEC (https://api.indec.gob.ar). Usa dos servicios de datos:
  - comercio_exterior_importacion_bienes: las importaciones con su valor CIF en dólares.
    Se piden ya sumadas por la API, por mes (Periodo) y uso económico (uso_economico_cod).
  - comercio_exterior_nomenclaturas: el nombre de cada código (1 = Bienes de Capital, etc.).

Resultado: data_extracted.csv, una fila por mes y uso económico, con el valor, la participación
en el total del mes y la variación contra el mismo mes del año anterior.

Uso: python extraer_importaciones_indec.py   (necesita INDEC_API_TOKEN en el archivo .env)
"""
import os
import sys
import time

import pandas as pd
import requests
from dotenv import load_dotenv

BASE_URL = "https://api.indec.gob.ar/v1/"  # la barra final es obligatoria
TABLA_IMPORTACIONES = "comercio_exterior_importacion_bienes"
TABLA_NOMENCLATURAS = "comercio_exterior_nomenclaturas"
POR_PAGINA = 1000  # máximo de filas que devuelve la API por pedido
MESES = 12  # "el último año": los últimos 12 meses que publicó el INDEC
# Se piden 28 meses hacia atrás: 24 para comparar cada mes con el del año anterior,
# más el atraso con que el INDEC publica (en noviembre, el último dato es de septiembre).
MESES_A_PEDIR = 28
ARCHIVO_SALIDA = "data_extracted.csv"


class ErrorAPI(Exception):
    """Un problema que se le informa al usuario con un mensaje claro, sin traceback."""


def leer_token():
    """Lee el token del archivo .env. Nunca se escribe en el código."""
    load_dotenv()
    token = os.getenv("INDEC_API_TOKEN", "").strip()
    if not token:
        raise ErrorAPI(
            "No encontré la variable INDEC_API_TOKEN. Creá un archivo .env (podés copiar .env.example) "
            "con el token que generás en https://api.indec.gob.ar, en 'Gestionar la cuenta'."
        )
    return token


def pedir(sesion, tabla, params, intentos=4):
    """Hace un GET a un servicio de la API y devuelve la lista de filas.

    Si la API está saturada (429), falla el servidor (5xx) o no hay conexión, espera y reintenta.
    Los errores que no se arreglan reintentando (401, 403, 404, 400) se informan enseguida.
    """
    url = BASE_URL + tabla
    motivo = ""
    for intento in range(1, intentos + 1):
        espera = 2**intento
        try:
            r = sesion.get(url, params=params, timeout=60)
        except requests.exceptions.Timeout:
            motivo = "la API tardó demasiado en responder"
        except requests.exceptions.ConnectionError:
            motivo = "no se pudo conectar con api.indec.gob.ar (revisá la conexión o si la API está caída)"
        except requests.exceptions.RequestException as e:
            raise ErrorAPI(f"{tabla}: el pedido falló ({e.__class__.__name__}).") from None
        else:
            if r.status_code == 200:
                try:
                    datos = r.json()
                except ValueError:
                    raise ErrorAPI(f"{tabla}: la API respondió 200 pero el contenido no es JSON.") from None
                if not isinstance(datos, list):
                    raise ErrorAPI(f"{tabla}: la API no devolvió una lista de filas.")
                return datos
            if r.status_code == 401:
                raise ErrorAPI(
                    "La API rechazó el token (401). Revisá que esté bien copiado en .env; "
                    "si venció, generá otro en 'Gestionar la cuenta' de api.indec.gob.ar."
                )
            if r.status_code == 403:
                raise ErrorAPI(f"{tabla}: el token no tiene permiso para este servicio (403).")
            if r.status_code == 404:
                raise ErrorAPI(
                    f"No existe el servicio '{tabla}' (404). Revisá el nombre en https://api.indec.gob.ar/datasets."
                )
            if r.status_code == 400:
                raise ErrorAPI(f"{tabla}: la API dice que el pedido está mal armado (400): {r.text[:300]}")
            if r.status_code == 429 or r.status_code >= 500:
                motivo = f"la API respondió {r.status_code}"
                espera = int(r.headers.get("Retry-After", "0")) if r.headers.get("Retry-After", "").isdigit() else espera
            else:
                raise ErrorAPI(f"{tabla}: respuesta inesperada de la API ({r.status_code}): {r.text[:300]}")
        if intento < intentos:
            print(f"  Intento {intento} de {intentos}: {motivo}. Reintento en {espera} s...")
            time.sleep(espera)
    raise ErrorAPI(f"{tabla}: {motivo}, y siguió fallando después de {intentos} intentos. Probá más tarde.")


def pedir_todo(sesion, tabla, params):
    """Recorre las páginas de 1000 filas hasta que llega una incompleta."""
    filas = []
    while True:
        lote = pedir(sesion, tabla, {**params, "limit": POR_PAGINA, "offset": len(filas)})
        filas.extend(lote)
        if len(lote) < POR_PAGINA:
            return filas


def extraer(sesion, desde):
    """Las importaciones sumadas por mes y uso económico desde `desde` (AAAAMM), y los nombres de los usos."""
    importaciones = pedir_todo(
        sesion,
        TABLA_IMPORTACIONES,
        {
            # La API suma el valor CIF de todas las operaciones de cada mes y uso económico
            "select": "Periodo,uso_economico_cod,valor_cif_usd:valor_CIF.sum()",
            "Periodo": f"gte.{desde}",
            "order": "Periodo,uso_economico_cod",
        },
    )
    nomenclatura = pedir_todo(
        sesion,
        TABLA_NOMENCLATURAS,
        {
            "select": "codigo,codigo_descripcion",
            "nombre_columna": "eq.uso_economico_cod",
            "order": "codigo",
        },
    )
    return importaciones, nomenclatura


def transformar(importaciones, nomenclatura, meses=MESES):
    """Arma la tabla limpia: los últimos `meses` meses, con el nombre de cada uso económico,
    el valor en millones de dólares, la participación y la variación interanual."""
    df = pd.DataFrame(importaciones)
    esperadas = {"Periodo", "uso_economico_cod", "valor_cif_usd"}
    if df.empty or not esperadas.issubset(df.columns):
        raise ErrorAPI(f"La API no devolvió las columnas esperadas {sorted(esperadas)}: llegó {list(df.columns)}.")

    nombres = {
        str(f["codigo"]): " ".join(str(f["codigo_descripcion"]).split())  # saca espacios de más
        for f in nomenclatura
    }

    df["uso_economico_cod"] = df["uso_economico_cod"].astype(str)
    df["fecha"] = pd.to_datetime(df["Periodo"].astype(str), format="%Y%m")
    df["valor_cif_usd"] = pd.to_numeric(df["valor_cif_usd"], errors="coerce").fillna(0)

    # El valor del mismo mes del año anterior, para la variación interanual
    anterior = df[["fecha", "uso_economico_cod", "valor_cif_usd"]].copy()
    anterior["fecha"] = anterior["fecha"] + pd.DateOffset(years=1)
    anterior = anterior.rename(columns={"valor_cif_usd": "valor_anio_anterior"})
    df = df.merge(anterior, on=["fecha", "uso_economico_cod"], how="left")

    # Los últimos `meses` meses publicados
    ultimo = df["fecha"].max()
    inicio = ultimo - pd.DateOffset(months=meses - 1)
    df = df[df["fecha"] >= inicio].copy()
    if df["fecha"].nunique() < meses:
        print(f"  Aviso: llegaron {df['fecha'].nunique()} meses de los {meses} esperados.")

    df["uso_economico"] = df["uso_economico_cod"].map(nombres).fillna("Sin nombre en la nomenclatura")
    df["valor_cif_millones_usd"] = (df["valor_cif_usd"] / 1e6).round(2)
    total_mes = df.groupby("fecha")["valor_cif_usd"].transform("sum")
    df["participacion_pct"] = (df["valor_cif_usd"] / total_mes * 100).round(2)
    variacion = (df["valor_cif_usd"] / df["valor_anio_anterior"] - 1) * 100
    df["var_interanual_pct"] = variacion.replace([float("inf"), float("-inf")], float("nan")).round(1)
    df["periodo"] = df["fecha"].dt.strftime("%Y-%m")

    columnas = ["periodo", "uso_economico_cod", "uso_economico", "valor_cif_millones_usd", "participacion_pct", "var_interanual_pct"]
    return df.sort_values(["periodo", "uso_economico_cod"])[columnas].reset_index(drop=True)


def main():
    try:
        token = leer_token()
        sesion = requests.Session()
        sesion.headers.update({"Authorization": f"Bearer {token}", "Accept": "application/json"})

        desde = (pd.Period(pd.Timestamp.today(), freq="M") - MESES_A_PEDIR).strftime("%Y%m")
        print(f"Pidiendo a la API del INDEC las importaciones por uso económico desde {desde}...")
        importaciones, nomenclatura = extraer(sesion, desde)
        print(f"  Llegaron {len(importaciones)} filas de importaciones y {len(nomenclatura)} códigos de uso económico.")

        tabla = transformar(importaciones, nomenclatura)
        try:
            tabla.to_csv(ARCHIVO_SALIDA, index=False, encoding="utf-8")
        except OSError as e:
            raise ErrorAPI(f"No pude guardar {ARCHIVO_SALIDA}: {e}") from None
    except ErrorAPI as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1

    print(f"Listo: {ARCHIVO_SALIDA} con {len(tabla)} filas, de {tabla.periodo.min()} a {tabla.periodo.max()}.")
    ultimo = tabla[tabla.periodo == tabla.periodo.max()]
    print(f"\nImportaciones de {tabla.periodo.max()} por uso económico (millones de USD CIF):")
    print(ultimo[["uso_economico", "valor_cif_millones_usd", "participacion_pct", "var_interanual_pct"]].to_string(index=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
